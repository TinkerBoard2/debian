rockchip-vaapi-driver
=================

Rockchip VA-API Driver
