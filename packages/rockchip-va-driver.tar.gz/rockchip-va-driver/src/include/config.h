#ifndef _CONFIG_H_
#define _CONFIG_H_

#define VA_DRIVER_INIT_FUNC __vaDriverInit_0_36

#endif
